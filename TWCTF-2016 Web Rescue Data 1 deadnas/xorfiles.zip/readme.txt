***********************************
XorFiles v1.0
Copyright (c) 2002 Nir Sofer

Web site: http://nirsoft.cjb.net
***********************************

Description
===========
This utility perform a logical exclusion ("XOR") on 2 files, and saves the result into the destination file.
You can use it for viewing the difference locations between 2 binary files. In the destination file, the equal bytes in the 2 files are represented by zero value. (A XOR A = 0)


License
=======
This utility is released as freeware. You can freely use and distribute it.
If you distribute this utility, you must include all files in the distribution package including the readme.txt, without any modification !
 

Disclaimer
==========
The software is provided "AS IS" without any warranty, either expressed or implied,
including, but not limited to, the implied warranties of merchantability and fitness
for a particular purpose. The author will not be liable for any special, incidental,
consequential or indirect damages due to loss of data or any other reason. 

 
Using XorFiles
===============
The XorFiles doesn't require any installation process. You can run it from any folder you want.
In order to use, follow the instructions below:
1. Select or type all 3 files with full path. 
2. Click the "Start" button.
3. The XOR result of the 2 first files will be saved into the destination file.
 

Feedback
========
If you have any problem, suggestion, comment, or you found a bug in my utility, you can send a message to nirsofer@yahoo.com
